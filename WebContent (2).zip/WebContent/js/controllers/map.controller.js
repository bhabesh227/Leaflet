(function () {
    'use strict';
 
    myModule
        .controller('MapController', MapController);
 
    MapController.$inject = ['$scope', '$rootScope', 'ItemService'];
    
    function MapController($scope, $rootScope, ItemService) {
    	
    	$scope.$on('parentItems', function(event, data) {
    	   // console.log('Data ' + data)
    	    loadMap();
    	});
    	
    	$scope.$on('childItems', function(event, data) {
    	    var subItems = data;    	    
    	    var selectedItems = $rootScope.selectedItems;
    	    
    	    //console.dir(subItems);
    	    //console.dir(selectedItems);
    	    
    	    for(var i in selectedItems) {
    	    	console.log('Parent' + selectedItems[i].itemId);
    	    	
    	    	for(var j in subItems) {
    	    		//console.log(subItems[j].parentId);
    	    		if(subItems[j].parentId === selectedItems[i].itemId) {
    	    			console.log('Child' + subItems[j].itemId);
    	    			addMarkerToMap(subItems[j]);
    	    		}
    	    	}
    	    }
    	   // loadMap();
    	});
    	
    	
 
 
        (function initController() {
           /* 
        	$scope.items = [];
        	
        	ItemService.getItems()
            .then(
            	function(result) {
            		
            		$scope.items = result;
            		loadMap();
            		
            	}, function(error) {
            	
            		console.log(error.statusText);
            	}); */
        	//loadMap();
        })();
        var map;
        var LeafIcon;
        
        function addMarkerToMap(item) {
        	var smarker = L.marker([item.itemLat, item.itemLong], {icon: new LeafIcon({iconUrl: 'images/leaf-red.png'})})
	    	.addTo(map).on('click', function() {
	            this.stopBouncing();
	        })
	        .bindPopup('<img src="'+ item.itemImage +'" width="100" height="100" /> <br/>' + 'Bus' + item.itemId);
        	
        	if(item.itemFlag){
		    	smarker.bounce();
		    }
        }
        
        function loadMap() {
        	
        	//initialize the map
        	map = L.map('itemmap').setView([42.35, -71.04], 13);
        	
        	//base tile
        	L.tileLayer('http://tiles.mapc.org/basemap/{z}/{x}/{y}.png',
				{
				  attribution: 'Tiles by <a href="http://mapc.org">MAPC</a>, Data by <a href="http://mass.gov/mgis">MassGIS</a>',
				  maxZoom: 17,
				  minZoom: 9
				}).addTo(map);
        	
        	// bus lanes
        	L.tileLayer('http://tiles.mapc.org/trailmap-onroad/{z}/{x}/{y}.png',
	        	{
	        	  maxZoom: 17,
	        	  minZoom: 9
	        	}).addTo(map);
        	
        	LeafIcon = L.Icon.extend({
        	    options: {
        	        shadowUrl: 'images/leaf-shadow.png',
        	        iconSize:     [38, 95],
        	        shadowSize:   [50, 64],
        	        iconAnchor:   [22, 94],
        	        shadowAnchor: [4, 62],
        	        popupAnchor:  [-3, -76]
        	    }
        	});
        	
        	$.each( $scope.items, function( key, val ) {
        		
        		//console.log(val.itemLat)
        		var marker = L.marker([val.itemLat, val.itemLong], {icon: new LeafIcon({iconUrl: 'images/leaf-green.png'})})
		    	.addTo(map).on('click', function() {
		            this.stopBouncing();
		        })
		        .bindPopup('<img src="'+ val.itemImage +'" width="100" height="100" /> <br/>'  + val.itemName);
        		
        		if(val.itemFlag){
			    	marker.bounce();
			    }
        	});
        }
    }
 
})();