(function () {
    'use strict';
 
    myModule
        .controller('ItemController', ItemController);
 
    ItemController.$inject = ['$scope', '$rootScope', 'ItemService'];
    
    function ItemController($scope, $rootScope, ItemService) {
 
        (function initController() {
            //
        	$scope.items = [];
        	
        	ItemService.getItems()
            .then(
            	function(result) {
            		
            		$scope.items = result;
            		//console.log('$scope.items: ' + $scope.items)
            		$scope.$broadcast('parentItems', $scope.items);
            		
            	}, function(error) {
            	
            		console.log(error.statusText);
            	}); 
        	 
        	$scope.subItems = [];
        	
        	ItemService.getSubItems()
            .then(
            	function(result) {
            		
            		$scope.subItems = result;
            		//console.log('Subitems: ' + $scope.subItems)
            		
            	}, function(error) {
            	
            		console.log(error.statusText);
            	});
        	
        })();
        
        
        $scope.showItem = function(id, index) {
        	
        	var items = $scope.items;
        	$rootScope.showAll = false;
        	
        	if(items[index].selected) {

        		$rootScope.selectedItems.push(items[index]);

        	}
        	else {
        		for (var i = 0; i < $rootScope.selectedItems.length; i++) {
        			
                    var item = $rootScope.selectedItems[i];
                  
                    if (item.itemId === id) {
                    	$rootScope.selectedItems.splice(i, 1);
                        break;
                    }
                }
            	
        	}
        	$scope.$broadcast('childItems', $scope.subItems);
        };
        
        $rootScope.showAllItems = function() {

    		$rootScope.selectedItems = [];
    		console.log($rootScope.selectedItems)
        	if($rootScope.showAll) {
        		
        		$scope.setAllItemSelected(true);
        		
        		for(var i in $scope.items) {
        			$rootScope.selectedItems.push($scope.items[i]);
        		}
        	}
        	else {

        		$scope.setAllItemSelected(false);
        	}
        };
        
        $scope.showItemModal = function(item) {
        	
        	$scope.currentItem = item;
        };
        
        $scope.setAllItemSelected = function(flag) {
        	
        	for(var i in $scope.items) {
        		
        		$scope.items[i].selected= flag;
        	}
        };
        


        $scope.itemImgWidth = 100;

        $scope.increaseItemImgWidth = function(){
        	
        	if($scope.itemImgWidth != 200){
        		$scope.itemImgWidth+= 10;
        	}
        };

        $scope.decreaseItemImgWidth = function(){
        	
        	if($scope.itemImgWidth != 50){
        		$scope.itemImgWidth-= 10;
        	}
        };
        
        $scope.setFullItemImgWidth = function() {
        	
        	$scope.itemImgWidth = 100;
        };
        
    }
 
})();