var myModule = angular.module('imageApp', ['ui.router']);

myModule.config(function($stateProvider, $urlRouterProvider) {
    
    $urlRouterProvider.otherwise('/home');
    
    $stateProvider
    
    // State home
    .state('home', {
    	url : '/home',
    	template : 'This is home page'
    })
 
    // State Items and nested views
    .state('items', {
        abstract: true,
        controller : 'ItemController',
        templateUrl : 'partials/items.html'
    })
    
    .state('items.list', {
    	url : '/list',
    	views: {
    	      "list": { templateUrl : 'partials/items-list.html'},
    	      "map": {     	    	  
    	    	  template : '<div id="itemmap"></div>',
    	    	  controller : 'MapController'
    	      }
    	}
    })
    
    .state('items.list.modal', {
    	url : '/modal',
    	views: {
  	      "modal": { templateUrl : 'partials/modal.html'}
    	}
    })

    
});