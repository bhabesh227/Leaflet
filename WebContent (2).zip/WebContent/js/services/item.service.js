(function () {
    'use strict';
 
    myModule
        .service('ItemService', ItemService);
 
    ItemService.$inject = ['$http', '$q'];
    
    function ItemService($http, $q) {
    	
    	var deferred = $q.defer();
    	
    	this.getItems = function() {
    		
    		return $http.get('js/items.json')
    			.then(function(response) {
    				
    				deferred.resolve(response.data);
    				return deferred.promise;
    				
    			}, function(response) {
    				
    				deferred.reject(response);				
    				return deferred.promise;
    			});
    	};
    	
    	var sdeferred = $q.defer();
    	
    	this.getSubItems = function() {
    		
    		return $http.get('js/sub-items.json')
    			.then(function(response) {
    				
    				sdeferred.resolve(response.data);
    				return sdeferred.promise;
    				
    			}, function(response) {
    				
    				sdeferred.reject(response);				
    				return sdeferred.promise;
    			});
    	};

    }
})();